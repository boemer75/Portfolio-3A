package com.example.relgio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.relgio.R;

import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {
    int Somamin, Somahora, Diminuihora, Diminuimin;
    EditText Hi, Hf, Mi, Mf;
    TextView Rh, Rm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        Hi = findViewById(R.id.hora_ini);
        Hf = findViewById(R.id.hora_fin);
        Mi = findViewById(R.id.min_ini);
        Mf = findViewById(R.id.min_fin);
        Rm = findViewById(R.id.Rm);
        Rh = findViewById(R.id.Rh);
    }


    public void calculaSoma(View s) {
        int a, b, c, d;
        a = Integer.parseInt(Hi.getText().toString());
        b = Integer.parseInt(Hf.getText().toString());
        c = Integer.parseInt(Mi.getText().toString());
        d = Integer.parseInt(Mf.getText().toString());
        Somahora = a + b;
        Somamin = c + d;
        while (Somamin > 59) {
            Somahora++;
            Somamin = Somamin - 60;


        }
        Rm.setText(Somamin + "");
        while (Somahora < 0) {
            Somahora--;
            Somamin = Somamin + 60;

        }
        Rh.setText(Somahora + "");


        Rm.setVisibility(View.VISIBLE);
        Rh.setVisibility(View.VISIBLE);
    }

    public void Subtrair(View s) {
        int e, f, g, h;
        e = Integer.parseInt(Hi.getText().toString());
        f = Integer.parseInt(Hf.getText().toString());
        g = Integer.parseInt(Mi.getText().toString());
        h = Integer.parseInt(Mf.getText().toString());
      while(g>59){
           e ++;
        g= g-60;
        }


       while (h>59){
           f ++;
            h = h-60;

        }
       if(f>=e) {
           Diminuihora = f - e;
           if (h >= g) {
               Diminuimin = h - g;
           } else {
               Diminuimin = g - h;
           }
       }
          else {
              Diminuihora= e - f;
               Diminuimin = g-h;
          }

       Diminuimin = g - h ;
        while (Diminuimin < 0) {
            Diminuihora--;
            Diminuimin = Diminuimin + 60;


        }
        Rm.setText(Diminuimin + "");

        Rh.setText(Diminuihora + "");
        Rm.setVisibility(View.VISIBLE);
        Rh.setVisibility(View.VISIBLE);
    }


    public void Reseta(View r) {
        Hi.setText("");
        Hf.setText("");
        Mi.setText("");
        Mf.setText("");
        Rm.setText("");
        Rh.setText("");

    }
}

